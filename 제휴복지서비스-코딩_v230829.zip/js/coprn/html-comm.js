//브라우저 버전 체크
var IEVersionCheck = function() {

    var word,
        version = "N/A",
        agent = navigator.userAgent.toLowerCase(),
        name = navigator.appName;

    // IE old version ( IE 10 or Lower )
    if ( name == "Microsoft Internet Explorer" ) word = "msie ";

    else {
        // IE 11
        if ( agent.search("trident") > -1 ) word = "trident/.*rv:";

        // IE 12  ( Microsoft Edge )
        else if ( agent.search("edge/") > -1 ) word = "edge/";
    }

    var reg = new RegExp( word + "([0-9]{1,})(\\.{0,}[0-9]{0,1})" );
    if (  reg.exec( agent ) != null  )
        version = RegExp.$1 + RegExp.$2;

    return version;
};


//layer popup (타켓지정)
function layer_popup(obj){
	if($(obj).is(":hidden")){
		$(obj).show();															//레이어팝업 show
		$('body').after('<div class="blackBg"></div>'); 						//검은 불투명 배경 show

		//position > absolute에 따른 높이 제어
		var winHeight = $(window).height()/2,
			objHeight = $(obj).height()/2,
			scrollHeight = $(document).scrollTop(),
			winHeight2 = $(window).height(),
			scrollHeight2 = $(window).scrollTop(),
			popupHeight = $('.popup-area').outerHeight(true);
        
        var popupWidth = $(obj + '.popup-content > .content').outerWidth(true);

		if(scrollHeight2 < 100 || winHeight2 < popupHeight) {					//스크롤 값이 없는경우 혹은 팝업크기보다 작은경우 실행
			$('.popup-area').animate( {'top' : '50px'}, 200);					//top이 0인경우
            $(obj).css('width', popupWidth);
            
            //position relative에 따른 추가 스타일
            $('#main').css('position', 'static');
		}
		else {
			$('.popup-area').animate( {'top' : scrollHeight+winHeight-objHeight}, 200);
            $(obj).css('width', popupWidth);
            
            //position relative에 따른 추가 스타일
            $('#main').css('position', 'static');
		}

		//배경클릭시 닫기
		$('.blackBg').click(function(){
			$(obj).hide();
			$(this).remove();
			$('.popup-area').css('top', '0px');								//애니에 따른 추가
            
            //position relative에 따른 추가 스타일
            $('#main').css('position', 'static');
		});
	}
	else {
		$(obj).hide();
		$('.blackBg').remove();
		$('.popup-area').css('top', '0px');									//애니에 따른 추가
        
        //position relative에 따른 추가 스타일
		$('#main').css('position', 'static');
	}

	//자동 닫기 추가
	$(obj+' .close').on('click', function() {
		$(obj).hide();
		$('.blackBg').remove();
		$('.popup-area').css('top', '0px');									//애니에 따른 추가
        
        //position relative에 따른 추가 스타일
		$('#main').css('position', 'static');
	});
}

function layer_close(obj){
	$(obj).hide();
	$('.blackBg').remove();
	$('.popup-area').css('top', '0px');										//애니에 따른 추가
    
    //position relative에 따른 추가 스타일
	$('#main').css('position', 'static');
}


//주메뉴 Focus (웹접근성)
function MenuFocus() {
    var speed = 0,
        obj = '#lnb-menu > ul > li',     	 //object
        item = '#lnb-menu .menu-depth',      //selector
        focusOut = '#side-menu ul li a';     //focus out

    $(obj).focusin(function(event) {
        if($(this).children(item).is(":hidden")) {
            $(item).removeClass('focusActive');
            $(this).children(item).addClass('focusActive');
            
            //+, - 버튼이미지 추가
            //$(obj).removeClass('select');
            //$(this).addClass('select');
        }
    });

    $(focusOut).focusin(function() {
        $(item).removeClass('focusActive');
    });
    
    $('.gnb-menu').focusin(function() {
        $(item).removeClass('focusActive');
    });
    $('#main-key-img-pager').focusin(function() {
        $(item).removeClass('focusActive');
    });
}


//주메뉴 (모바일)
function MobileMenu() {
	$('#lnb-menu > ul > li > a').click(function(event) {
		var speed = 350;
		var winWidth = $(window).outerWidth();
		
		if(winWidth <= 1023) {
			if ($(this).next('#lnb-menu .menu-depth').css('display')==='none') {
				$('#lnb-menu .menu-depth').slideUp(speed);
				$(this).next('#lnb-menu .menu-depth').slideDown(speed);
				$('#lnb-menu > ul > li > a').removeClass('on');
				$(this).addClass('on');
			}
			//else {
			//	$('#lnb-menu .menu-depth').slideUp(speed);
			//	$('#lnb-menu > ul > li > a').removeClass('on');
			//}
			
			//모바일 링크 클릭시 무력화
			//return false;
		}
	});
}


//아코디언
function accordion(obj) {
	var speed = 400;
	
	$(obj + ' dl').on('click', function() {
		if ($(this).find('dd').css('display')==='none') {
			$(this).find('dd').slideDown(speed);
			
			$(this).on('.open').removeClass('active');
			$(this).on('.open').addClass('active');
		}
		else {
			$(this).find('dd').slideUp(speed);
			$(this).on('.open').removeClass('active');
		}
		
		return false;
	});
}


//tab panel (detailTabMenu1)
function tabPanel(params) {
	var defaults = {
		container: "#tabs", 	//item wrap id
		firstItem: "#tabs-1", 	//first show item
		active: 0 				//ul li > menu on
	};
	for (var def in defaults) { //array object 확인
		if (typeof params[def] === 'undefined') {
			params[def] = defaults[def];
		}
		else if (typeof params[def] === 'object') {
			for (var deepDef in defaults[def]) {
				if (typeof params[def][deepDef] === 'undefined') {
					params[def][deepDef] = defaults[def][deepDef];
				}
			}
		}
	};

	//변수선언
	var item = params.container+' ';
	var firstItem = params.firstItem;
	var active = params.active;


	$(item + '.tabPanel').css('display', 'none');				//전체 콘텐츠 hide
	$(firstItem).css('display', 'block');						//해당 콘텐츠 show
	$(item + '.nav-menu li').eq(active).addClass('active');		//해당 메뉴 active
	
	$(item+'.nav-menu li a').click(function() {
		var show = $(this).attr('href');
		//메뉴 css 추가
		$(item+'.nav-menu li').removeClass('active');
		$(this).parent().addClass('active');
		//tab panel show, hide
		$(item+' .tabPanel').css('display', 'none');
		$(show).css('display', 'block');

		return false;
	});
};

//tab panel (웹접근성용)
function tabPanel2(params) {
	var defaults = {
		container: "#tab-wrap",		//item wrap id
		active: 0					//show item
	};
	for (var def in defaults) { //array object 확인
		if (typeof params[def] === 'undefined') {
			params[def] = defaults[def];
		}
		else if (typeof params[def] === 'object') {
			for (var deepDef in defaults[def]) {
				if (typeof params[def][deepDef] === 'undefined') {
					params[def][deepDef] = defaults[def][deepDef];
				}
			}
		}
	};

	//변수선언
	var item = params.container+' ';
	var active = params.active;


	$(item + '.tab-contents').hide();												//전체 콘텐츠 hide
	$(item + '.tab-list > li').eq(active).find('.tab-contents').show();				//해당 콘텐츠 show
	$(item + '.tab-list > li').eq(active).find('.tab-menu').addClass('active');		//해당 메뉴 class active

	$(item + '.tab-menu').click(function() {
		$(item + '.tab-contents').hide();						//전체 콘텐츠 hide
		$(this).parents('li').find('.tab-contents').show();		//해당 콘텐츠 show
		$(item + '.tab-menu').removeClass('active');			//전체 메뉴 class hide
		$(this).addClass('active');								//해당 메뉴 class show

		return false;
	});
};


$(document).ready(function($) {	
	//ie하위 브라우저시 실행
    if(IEVersionCheck() == 8 || IEVersionCheck() == 7 || IEVersionCheck() == 5) {
        var error_browser = '';
        error_browser += '<div class="not-browser">';
        error_browser += '  <div class="warning"><span></span></div>';
        error_browser += '  <h1 class="error-title">현재 사용중인 브라우저는 지원되지 않습니다.<br><span class="sub">(In this broser isn&#39;t supported.)</span></h1>';
        error_browser += '  <p class="error-text">Microsoft의 지원 종료 된 브라우저를 사용하고 있습니다.</p>';
        error_browser += '  <p class="error-text">최신 버전의 Internet Explorer, Chroem, Safari, Firefox, Microsoft Edge<br>브라우저를 이용해 주세요.</p>';
        error_browser += '  <div style="margin-top: 20px;"><a href="https://www.google.co.kr/chrome/browser/desktop/index.html" class="btn blue">크롬 브라우저 다운로드</a></div>';
        error_browser += '</div>';

        $('body').html(error_browser);
    }
    else {
    	
    	MenuFocus(); //주메뉴 Focus (웹접근성)
    	MobileMenu(); //모바일 주메뉴
		
		
    	//모바일 주메뉴
    	var speed = 350; 
    	$("#mainMenu").click(function(event) { 
    		$("#menu-area").animate({right: "0"}, speed);
    		//$('#wrap').after('<div class="blackBg"></div>'); 
			$('#search-lay').hide();
			$('#search-btn').removeClass('hidden');
    	});
    	$(".menu-close").click(function(event) { 
    		$("#menu-area").animate({right: "-100%"}, speed);
    		//$('.blackBg').remove();
    	});
    	
    	
    	//FAQ 아코디언 실행	
    	accordion('.board-accordion.accordionFaq');
		
		
    	//Top 버튼
    	// hide .go-top first
    	//$(".go-top").hide();
		
    	
    	// fade in .go-top
    	$(function () {
    		// scroll body to 0px on click
    		$('.go-top a').click(function () {
    			$('body,html').animate({
    				scrollTop: 0
    			}, 800);
    			return false;
    		});
    	});
    }
	
});


/* ====================================================================================================================
* window resize
* ====================================================================================================================*/
$(window).resize(function(){
	if(this.resizeTO) {
		clearTimeout(this.resizeTO);
	}
	this.resizeTO = setTimeout(function() {
		$(this).trigger('resizeEnd');
	}, 300);
});
$(window).on('resizeEnd', function() {
	//main_menuCheck();
    
    var winWidth = $(window).outerWidth();
	if(winWidth >= 1024) {
        //모바일에서 메뉴 닫지 않고 창 크기를 키우는 경우
        //$('#lnb-menu > ul > li > a').removeClass('on');
        $('#lnb-menu .menu-depth').removeClass('focusActive');
        //$('#lnb-menu .menu-depth').hide();
        //$('#lnb-menu .menu-3depth').hide();
        //$('.blackBg').hide();
    }	
    else {
        //$('#lnb-menu > ul > li').removeClass('on');
        $('.blackBg').show();
    };
});

//로딩중 표시
function showLoadingDiv(loadingMsg) {
	
	//로딩 메시지
	var loadingMsg = $.trim(loadingMsg);
	
	//로딩 메시지가 없으면
	if(loadingMsg.length < 1) {
		
		$("#loadingBar #div-ing").html("");
		$("#loadingBar #div-ing").hide();
	}
	//로딩 메시지가 있으면
	else {
		
		$("#loadingBar #div-ing").html(loadingMsg);
		$("#loadingBar #div-ing").show();
	}
	
	$("#loadingBar").show();
}

//로딩중 숨김
function hideLoadingDiv() {
	
	$("#loadingBar").hide();
}