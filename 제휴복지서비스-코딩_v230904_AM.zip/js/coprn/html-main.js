$(document).ready(function(){
	//메인이미지
	var swiper = new Swiper(".mainVisual-slide", {
		slidesPerView: 1,
        spaceBetween: 30,
        //loop: true,
		autoplay: {
		  delay: 8000,
		  disableOnInteraction: "false",
		},
		speed : 1000,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
		speed : 1000,
	});
});